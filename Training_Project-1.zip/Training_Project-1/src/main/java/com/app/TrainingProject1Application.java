package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(TrainingProject1Application.class, args);
	}

}
